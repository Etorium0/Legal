
  # Design System for Legal-Tech

  This is a code bundle for Design System for Legal-Tech. The original project is available at https://www.figma.com/design/MC1qINOv4zjERM2GyUfJsr/Design-System-for-Legal-Tech.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  